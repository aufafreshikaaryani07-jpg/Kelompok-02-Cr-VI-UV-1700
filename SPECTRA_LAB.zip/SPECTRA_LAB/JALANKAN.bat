@echo off
cd /d "%~dp0"
echo Memasang paket (hanya lama saat pertama kali)...
python -m pip install -r requirements.txt
echo Membuka SPECTRA LAB di browser...
python -m streamlit run app.py
pause
